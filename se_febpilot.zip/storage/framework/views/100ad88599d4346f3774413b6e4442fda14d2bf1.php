<?php $__env->startSection('content'); ?>
<script src="//cdn.ckeditor.com/4.5.9/standard/ckeditor.js"></script>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">        
            <div class="panel panel-default">
                <div class="panel-heading">Create a video</div>

                <div class="panel-body">
                   <form action="<?php echo e(url('videos/'.$video->id)); ?>" method="post">
                   <?php echo e(method_field('PATCH')); ?>


						<div class="form-group form-inline">
							<label for="name" class="col-sm-2">Video Name: </label>
							<input type="text" name="name"  placeholder="Video Name" class="form-control" required="required" value="<?php echo e($video->name); ?>">
						</div>

						<div class="form-group form-inline">
							<label for="short_title" class="col-sm-2">Short Title: </label>
							<input type="text" name="short_title" placeholder="Short Title" class="form-control" value="<?php echo e($video->short_title); ?>">
						</div>

						<div class="form-group form-inline">
							<label for="youtube_link" class="col-sm-2">YouTube Link: </label>
							<input type="text" name="youtube_link" placeholder="YouTube Link" class="form-control" value="<?php echo e($video->youtube_link); ?>">
						</div>

						<div class="form-group form-inline">
							<label for="village" class="col-sm-2">Week: </label>
							
							<select name="video_stack_id" class="form-control" required="required">
							 <?php foreach($videostacks as $videostack): ?>
								<option value="<?php echo e($videostack->id); ?>" <?php echo e(($video->video_stack_id == $videostack->id) ? 'selected="selected"' : ''); ?>><?php echo e($videostack->short_title); ?> (<?php echo e($videostack->name); ?>)</option>
							<?php endforeach; ?>
							</select>
						</div>

						<div class="form-group form-inline">
							<label for="liked" class="col-sm-2">Liked: </label>
							
							<select name="liked" class="form-control" required="required">
								<option value="Extremely Disliked" <?php echo e(($video->liked == "Extremely Disliked" ? 'selected="selected"' : '')); ?>>Extremely Disliked</option>
								<option value="Disliked" <?php echo e(($video->liked == "Disliked" ? 'selected="selected"' : '')); ?>>Disliked</option>
								<option value="Misunderstood" <?php echo e(($video->liked == "Misunderstood" ? 'selected="selected"' : '')); ?>>Misunderstood</option>
								<option value="Not Watched" <?php echo e(($video->liked == "Not Watched" ? 'selected="selected"' : '')); ?>>Not Watched</option>
								<option value="Watched" <?php echo e(($video->liked == "Watched" ? 'selected="selected"' : '')); ?>>Watched</option>
								<option value="Liked" <?php echo e(($video->liked == "Liked" ? 'selected="selected"' : '')); ?>>Liked</option>
								<option value="Extremely Liked" <?php echo e(($video->liked == "Extremely Liked" ? 'selected="selected"' : '')); ?>>Extremely Liked</option>						
							</select>
						</div>

						<div class="form-group form-inline">
							<label for="short_title">General Feedback: </label>
							<textarea name="feedback" id="feedback" ><?php echo e($video->feedback); ?></textarea>
						</div>

						<div class="form-group form-inline">
							<label for="success_story">Success Story: </label>
							<textarea name="success_story" id="success_story"><?php echo e($video->success_story); ?></textarea>
						</div>
						

                   		<!-- Form Control-->
						<div class="form-group">
							<button type="submit" class="btn btn-primary">Create Video</button>
						</div>
						<?php echo e(csrf_field()); ?>

                   </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
CKEDITOR.replace( 'feedback');
CKEDITOR.replace( 'success_story');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>