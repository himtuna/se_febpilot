<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">        
            <div class="panel panel-default">
                <div class="panel-heading">Feedback from Women</div>

                <div class="panel-body">               
                

                <ul class="nav nav-tabs">
                    <?php $i=0; ?>
                    <?php foreach($villages as $village): ?>                    
                        <li <?php echo e(($i==0) ? 'class=active': ''); ?>><a data-toggle="tab" href="#menu<?php echo e($village->id); ?>"><?php echo e($village->name); ?> <span class="badge"> <?php echo e(count($village->members)); ?></span></a></li>
                        <?php $i++;?>
                    <?php endforeach; ?>
                    <li><a href="<?php echo e(url('members/create')); ?>" class="btn-success">+ Woman</a></li>
                  </ul>
                  <br>
                        
                        <div class="tab-content">
                            <?php $i=0; ?>
                            <?php foreach($villages as $village): ?>
                            
                            <div id="menu<?php echo e($village->id); ?>" class="tab-pane fade <?php echo e(($i==0) ? 'in active': ''); ?>">
                                
                                <?php foreach($members as $member): ?>
                                <?php if($member->village_id == $village->id): ?>
                                <div class="row">
                                <div class="col-sm-2">
                                <div class="thumbnail">
                                <img class="img-responsive user-photo" <?php if(isset($member->image)): ?> src="<?php echo e(url($member->image)); ?>" <?php else: ?> src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png" <?php endif; ?>>
                                <strong><?php echo e($member->name); ?></strong>
                                </div><!-- /thumbnail -->
                                </div><!-- /col-sm-1 -->

                                <div class="col-sm-10">
                                <div class="panel panel-default panel-comment">
                                <div class="panel-heading comment">
                                <strong><?php echo e($member->name); ?></strong>
                                </div>
                                <div class="panel-body">
                                
                                <?php if($member->feedback == NULL): ?>
                                <div class="alert alert-info"><p><strong>No Record Found!</strong> Feedback not available!</p></div>
                                <?php else: ?> 
                                <?php echo $member->feedback; ?>

                                <?php endif; ?>
                                
                                </div><!-- /panel-body -->
                                <div class="panel-footer">Village: <?php echo e($member->village->name); ?> 
                                <a href="<?php echo e(url('members/'.$member->id.'/edit')); ?>" class="pull-right"><i class="fa fa-pencil"></i> Edit Feedback</a>
                                </div>
                                </div><!-- /panel panel-default -->
                                </div><!-- /col-sm-5 -->
                                </div> 
                                <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        
                            <?php $i++; ?>
                            <?php endforeach; ?>
                        </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>