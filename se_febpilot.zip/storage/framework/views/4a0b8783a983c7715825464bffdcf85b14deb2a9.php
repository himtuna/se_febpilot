<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">        
            <div class="panel panel-default">
                <div class="panel-heading">Self Help Groups</div>

                <div class="panel-body">
                <a href="<?php echo e(url('self-help-groups/create')); ?>" class="btn btn-primary pull-right">+ Self Help Group</a>
                <div class="clear-fix"></div>
                    <table class="table table-hover table-bordered">
                        <thead>
                            <th>SHG Name</th>
                            <th>SHG Details</th>
                            <th>Socio-Economic Status</th>
                            <th>Member Details</th>                                                        
                            <th><i class="fa fa-cog"></i></th>
                        </thead>
                        <tbody>
                            <?php foreach($shgs as $shg): ?>

                            <tr id="<?php echo e($shg->id); ?>">
                            
                                <td>
                                    <strong><?php echo e($shg->name); ?></strong> <br> 
                                    <a href="<?php echo e(url('villages#'.$shg->village->id)); ?>"><?php echo e($shg->village->name); ?> Village</a> <br>
                                    <small>SHG Age: <?php echo e($shg->shg_age); ?><br>
                                    Phones issued: <?php echo e($shg->phones_count); ?> <br>
                                    Total Active Members: <?php echo e(count($shg->village->members)); ?></small> 
                                </td>
                                <td>
                                    <small> 
                                    SHG Coord.: <a href="<?php echo e(url('shg-coordinators#'.$shg->shg_coordinator->id)); ?>"><?php echo e($shg->shg_coordinator->name); ?></a><br>
                                    Samhu Saheli: <a href="<?php echo e(url('members/'.$shg->samhu_saheli['id'])); ?>"><?php echo e($shg->samhu_saheli['name']); ?></a><br>
                                    Is Samshu Saheli member: <?php echo e(($shg->samhu_saheli_member == 1) ? 'Yes': 'No'); ?><br>
                                    
                                    SHG Monthly Deposit: Rs. <?php echo e($shg->monthly_deposit); ?> <br>
                                    Bank Account: <?php echo e(($shg->bank_account == 1) ? 'Yes': 'No'); ?> <br>
                                    SHG Savings: Rs. <?php echo e($shg->savings); ?>

                                    </small> 
                                </td>                                
                                <td>
                                   <small>Economic: <span class="label <?php echo e(($shg->economic_status == 'High') ? 'label-success' : ''); ?> <?php echo e(($shg->economic_status == 'Medium') ? 'label-info' : ''); ?> <?php echo e(($shg->economic_status == 'Low') ? 'label-warning' : ''); ?>"><?php echo e($shg->economic_status); ?></span><br><?php echo e($shg->economic_status_detail); ?><br>
                                    Caste: <span class="label <?php echo e(($shg->caste_status == 'High') ? 'label-success' : ''); ?> <?php echo e(($shg->caste_status == 'Medium') ? 'label-info' : ''); ?> <?php echo e(($shg->caste_status == 'Low') ? 'label-warning' : ''); ?>"><?php echo e($shg->caste_status); ?></span><br><?php echo e($shg->caste_status_detail); ?></small>
                                </td>
                                <td>
                                    <small>
                                    Literacy Level: <?php echo e($shg->literacy_level); ?> <br>
                                    Average Age: <?php echo e($shg->women_age_avg); ?><br>
                                    Family Profession: <?php echo e($shg->family_profession); ?><br>
                                    Marital Status: <?php echo e($shg->women_marital_count); ?><br>                                  
                                    </small>                                    
                                </td>                                
                                <td><a href="<?php echo e(url('self-help-groups/'.$shg->id.'/edit')); ?>"><i class="fa fa-pencil"></i></a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>