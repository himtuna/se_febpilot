<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">        
            <div class="panel panel-primary">
                <div class="panel-heading">Feedbacks Woman by Woman, Video by Video</div>

                <div class="panel-body">
            		<ul class="nav nav-tabs col-sm-offset-3">
	                    <?php $i=0; ?>
	                    <?php foreach($videostacks as $videostack): ?>                    
	                        <li <?php echo e(($i==0) ? 'class=active': ''); ?>><a data-toggle="tab" href="#menu<?php echo e($videostack->id); ?>"><?php echo e($videostack->short_title); ?> <span class="badge"></span></a></li>
	                        <?php $i++;?>
	                    <?php endforeach; ?>
	                    <li><a href="<?php echo e(url('feedbacks/create')); ?>" class="btn-success">+ Feedback</a></li>
                    </ul>
	                    
	                     <div class="tab-content">
                            <?php $i=0; ?>
                            <?php foreach($videostacks as $videostack): ?>
                                <div id="menu<?php echo e($videostack->id); ?>" class="tab-pane fade <?php echo e(($i==0) ? 'in active': ''); ?>">
                                <!-- Video Pills -->
	                                

	                                <div class="container">
		                                <ul class="nav nav-pills nav-stacked col-sm-2">
		                                <?php $j=0; ?>
		                                <?php foreach($videostack->videos as $video): ?>									
											<li <?php echo e(($j==0) ? 'class=active': ''); ?>><a data-toggle="tab" href="#video<?php echo e($video->id); ?>"><?php echo e($video->short_title); ?> <span class="badge"></span></a></li>
											<?php $j++;?>
		                                <?php endforeach; ?>
		                                </ul>
		                                <!-- Video Pills Tabs -->
										<br>
		                                <div class="tab-content col-sm-offset-2">
		                                	
											<?php $j=0; ?>
				                            <?php foreach($videostack->videos as $video): ?>
				                                <div id="video<?php echo e($video->id); ?>" class="tab-pane fade <?php echo e(($j==0) ? 'in active': ''); ?>">
													<!-- Feedbacks -->
													<div class="row">
						                                <div class="col-sm-4">
						                                <div class="">
						                                <?php 
						                                if($video->youtube_link !=''){
						                                    $video_id = explode("?v=", $video->youtube_link);
						                                    $video_id = $video_id[1];
						                                }
						                                else $video_id = '';
						                                ?>
						                                <?php if($video_id != ''): ?>
						                                <iframe width="100%" src="https://www.youtube.com/embed/<?php echo e($video_id); ?>" frameborder="0" allowfullscreen></iframe><?php endif; ?>
						                                <strong><?php echo e($video->name); ?></strong>
						                                </div><!-- /thumbnail -->
						                                </div><!-- /col-sm-1 -->

						                                <div class="col-sm-4">
						                                <div class="panel panel-default panel-comment">
						                                
						                                <div class="panel-body">
						                                <?php echo e($video->video_stack->short_title); ?>: <?php echo e($video->video_stack->name); ?> <br>
						                                Video: <?php echo e($video->short_title); ?> <br>
						                                Overall Rating: <?php echo e($video->liked); ?><br>
						                                Other stats: 
						                                </div><!-- /panel-body -->
						                                
						                                </div><!-- /panel panel-default -->
						                                </div><!-- /col-sm-5 -->
					                                </div> <hr>


													<?php foreach($video->feedbacks as $feedback): ?>

														 <div class="row">
							                                <div class="col-sm-2">
							                                <div class="thumbnail">
							                                <img class="img-responsive user-photo" <?php if(isset($feedback->member->image)): ?> src="<?php echo e(url($member->image)); ?>" <?php else: ?> src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png" <?php endif; ?>>
							                                <strong><?php echo e($feedback->member->name); ?></strong>
							                                </div><!-- /thumbnail -->
							                                </div><!-- /col-sm-1 -->

							                                <div class="col-sm-6">
							                                <div class="panel panel-default panel-comment">
							                                <div class="panel-heading comment">
							                                <strong><?php echo e($feedback->member->name); ?></strong> <em><?php echo e($feedback->video_liked); ?> this video</em>
							                                </div>
							                                <div class="panel-body">
							                                
							                                <strong>Feedback:</strong><?php echo $feedback->detail; ?>

							                                <strong>Quote:</strong><?php echo $feedback->quote; ?>


							                                
							                                </div><!-- /panel-body -->
							                                <div class="panel-footer">Village: <?php echo e($feedback->member->village->name); ?> 
							                                <a href="<?php echo e(url('feedbacks/'.$feedback->id.'/edit')); ?>" class="pull-right"><i class="fa fa-pencil"></i> Edit Feedback</a>
							                                </div>
							                                </div><!-- /panel panel-default -->
							                                </div><!-- /col-sm-6 -->
						                                </div>
													<?php endforeach; ?>

													<!-- Feedbacks -->
								                </div>
							                <?php $j++; ?>    
						                    <?php endforeach; ?>
							                  
		                                </div>

		                            </div>
	                            </div>
	                            <?php $i++;?>
                            <?php endforeach; ?>
                        </div>
                  	</ul>
                   
                </div>
                <!-- Panel Body -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>