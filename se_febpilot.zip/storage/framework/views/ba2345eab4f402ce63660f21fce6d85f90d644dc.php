<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">        
            <div class="panel panel-default">
                <div class="panel-heading">SHG Coordinators</div>

                <div class="panel-body">               
                

                           <?php foreach($shg_coordinators as $shg_coordinator): ?>
                                <a name="<?php echo e($shg_coordinator->id); ?>"></a>
                                <div class="row">
                                <div class="col-sm-2">
                                <div class="thumbnail">
                                <img class="img-responsive user-photo" src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png">
                                <strong><?php echo e($shg_coordinator->name); ?></strong>
                                </div><!-- /thumbnail -->
                                </div><!-- /col-sm-1 -->

                                <div class="col-sm-10">
                                <div class="panel panel-default panel-comment">
                                <div class="panel-heading comment">
                                <strong><?php echo e($shg_coordinator->name); ?></strong>
                                </div>
                                <div class="panel-body">
                                
                                <?php if(isset($shg_coordinator->feedback)): ?>
                                <?php echo $shg_coordinator->feedback; ?>

                                <?php else: ?> <div class="alert alert-info"><p><strong>No Record Found!</strong> Feedback not available!</p></div>
                                <?php endif; ?>
                                <hr>
                                SHG Coordinator for Village(s):
                                <ul>
                                <?php foreach($shg_coordinator->villages  as $village): ?>
                                    <li>
                                    <a href="<?php echo e(url('villages/'.$village->id)); ?>"><?php echo e($village->name); ?></a>
                                    </li>
                                <?php endforeach; ?>
                                </ul>
                                </div><!-- /panel-body -->
                                <div class="panel-footer">Phone: <?php echo e($shg_coordinator->phone); ?> 
                                <a href="<?php echo e(url('shg_coordinators/'.$shg_coordinator->id.'/edit')); ?>" class="pull-right"><i class="fa fa-pencil"></i> Edit Feedback</a>
                                </div>
                                </div><!-- /panel panel-default -->
                                </div><!-- /col-sm-5 -->
                                </div> <!-- row -->

                            <?php endforeach; ?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>