<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">        
            <div class="panel panel-default">
                <div class="panel-heading">Villages</div>

                <div class="panel-body">
                <a href="<?php echo e(url('villages/create')); ?>" class="btn btn-primary pull-right">+ Village</a>
                <div class="clear-fix"></div>
                    <table class="table table-hover table-bordered">
                        <thead>
                            <th>Village Name</th>
                            <th>Self Help Group</th>                            
                            <th>Economic Status</th>
                            <th>Caste Status</th>
                            <th>Schemes</th>                            
                            <th><i class="fa fa-cog"></i></th>
                        </thead>
                        <tbody>
                            <?php foreach($villages as $village): ?>
                            <tr id="<?php echo e($village->id); ?>">
                                <td><strong><?php echo e($village->name); ?></strong> <br> <small><?php echo e($village->distance); ?> km from PPES</small>
                                <br><small>Total SHGs: <?php echo e($village->total_shgs); ?></small></td>
                                <td><a href="<?php echo e(url('self-help-groups#'.$village->self_help_groups[0]->id)); ?>"><?php echo e($village->self_help_groups[0]->name); ?></a> <br><small>SHG Coord. <a href="<?php echo e(url('shg-coordinators#'.$village->shg_coordinator->id)); ?>">
                                <?php echo e($village->shg_coordinator->name); ?></a></small></td>                                
                                <td><span class="label <?php echo e(($village->economic_status == 'High') ? 'label-success' : ''); ?> <?php echo e(($village->economic_status == 'Medium') ? 'label-info' : ''); ?> <?php echo e(($village->economic_status == 'Low') ? 'label-warning' : ''); ?>"><?php echo e($village->economic_status); ?></span>
                                    <br><?php echo e($village->economic_status_detail); ?></td>
                                <td><span class="label <?php echo e(($village->caste_status == 'High') ? 'label-success' : ''); ?> <?php echo e(($village->caste_status == 'Medium') ? 'label-info' : ''); ?> <?php echo e(($village->caste_status == 'Low') ? 'label-warning' : ''); ?>"><?php echo e($village->caste_status); ?></span><br><?php echo e($village->caste_status_detail); ?></td>
                                <td>
                                    DBP Scheme: <?php if($village->dbp_scheme == 1): ?> <span class="label label-success">Yes</span>
                                    <?php else: ?> <span class="label label-warning">No</span> <?php endif; ?>
                                    <br>
                                    Soap Making Scheme: <?php if($village->soap_making_scheme == 1): ?> <span class="label label-success">Yes</span>
                                    <?php else: ?> <span class="label label-warning">No</span> <?php endif; ?>
                                    <br>
                                    PPES Students: <?php if($village->ppes_students == 1): ?>  <span class="label label-success">Yes</span>
                                    <?php else: ?> <span class="label label-warning">No</span> <?php endif; ?><br>
                                    Govt Scheme: <?php echo e($village->govt_scheme); ?>

                                </td>                                
                                <td><a href="<?php echo e(url('villages/'.$village->id.'/edit')); ?>"><i class="fa fa-pencil"></i></a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>