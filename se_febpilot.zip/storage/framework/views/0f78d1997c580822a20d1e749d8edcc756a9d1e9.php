<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">        
            <div class="panel panel-default">
                <div class="panel-heading"><?php echo e($member->name); ?> from <?php echo e($member->village->name); ?></div>               

                <div class="panel-body"> 
                	<ul class="nav nav-tabs">
				    <li class="active"><a data-toggle="tab" href="#menu1">Basic Details</a></li>
				    <li><a data-toggle="tab" href="#menu2">Socio-Economic Background</a></li>
				    <li><a data-toggle="tab" href="#menu3">Survey</a></li>
				    <li><a data-toggle="tab" href="#menu4">Feedback</a></li>
				    <li><a  class="btn-default" href="<?php echo e(url('members/'.$member->id.'/edit')); ?>">Edit</a></li>
				  </ul>
				  <br>

					<div class="tab-content">
					    <div id="menu1" class="tab-pane fade in active">
					    	
						    Name: <?php echo e($member->name); ?> <br>
						    Village: <?php echo e($member->village->name); ?>


							
							
					    </div>

					    <div id="menu2" class="tab-pane fade">
					    	Economic Status: <span class="label <?php echo e(($member->economic_status == 'High') ? 'label-success' : ''); ?> <?php echo e(($member->economic_status == 'Medium') ? 'label-info' : ''); ?> <?php echo e(($member->economic_status == 'Low') ? 'label-warning' : ''); ?>"><?php echo e($member->economic_status); ?></span><br>
					    	Details<?php echo e($member->economic_status_details); ?>

					    	<hr>

					    	Caste Status: <span class="label <?php echo e(($member->caste_status == 'High') ? 'label-success' : ''); ?> <?php echo e(($member->caste_status == 'Medium') ? 'label-info' : ''); ?> <?php echo e(($member->caste_status == 'Low') ? 'label-warning' : ''); ?>"><?php echo e($member->caste_status); ?></span> <br>
					    	Details: <?php echo e($member->caste_status_detail); ?>

					     </div>
					    
					    <div id="menu3" class="tab-pane fade">

		
					
					    </div>
					    <div id="menu4" class="tab-pane fade">
					    	
					    		<label for="feedback">Feedback:</label>
					    			<?php echo $member->feedback; ?>

					     	
					     		<hr>
					     	
					    		<label for="success_story">Success Story: </label>
					    			<?php echo $member->success_story; ?>

					     				
				    	</div>

			    	</div><!-- tab Content -->

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>